import React from "react";
import CustomNavbar from "./CustomNavbar";

const Base = ({ title = "Welcome to Website", children }) => {
  return (
    <div className="container-fluid p-0 m-0">
      <CustomNavbar />
      <main className="container">{children}</main> {/* ✅ Ensures children are rendered */}
    </div>
  );
};

export default Base;
