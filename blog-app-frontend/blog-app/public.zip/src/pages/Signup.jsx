const Signup=()=>
    {
    
    
    return(
       <>
       <p>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur eius tenetur aliquid. Nobis ut recusandae fuga quos accusantium voluptatibus? Libero ipsa officiis itaque cumque iusto. Dicta quos expedita, neque officia saepe sequi non? Illum quibusdam maiores incidunt saepe tenetur asperiores eveniet, voluptatem nihil corporis alias repellendus velit nesciunt doloribus consequatur corrupti officia illo ipsam quam perspiciatis assumenda quidem dolores praesentium tempora maxime. Necessitatibus, temporibus molestiae. Quasi accusamus tenetur porro accusantium a eveniet!
    
       </p>
       </>
    )
    };
    
    export default Signup